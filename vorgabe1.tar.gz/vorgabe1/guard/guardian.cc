/*---------------------------------------------------------------------------*
 * Operating Systems I                                                       *
 *---------------------------------------------------------------------------*
 *                                                                           *
 *                              G U A R D I A N                              *
 *                                                                           *
 *---------------------------------------------------------------------------*/

/* METHODS  */
extern "C" void guardian (unsigned int slot);

/**
 * Main method for interrupt handleing.
 *
 * @param slot number of occurred interrupt
 */
void guardian (unsigned int slot) {
   
}
